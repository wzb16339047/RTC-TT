addpath(genpath(cd))
clear
addpath("../RTC")
%% Examples for testing the low-rank tensor models
% For detailed description of the sparse models, please refer to the Manual.
opts.mu = 1e-6;
opts.rho = 1.1;
opts.max_iter = 1000;
opts.DEBUG = 1;

% Initial parameters
Nway = [4 4 4 4 4 4 4 4 3];     % 9th-order dimensions for KA
n1 = 256;
n2 = 256;
n3 = 3;
I1 = 2; J1 = 2;                 % KA parameters
maxIter=1000;
epsilon = 1e-5;
T = double(imread('lena.bmp')); 
for noise = 0.1
    for mr = 0.5
        Y=imnoise(imread('lena.bmp'),'salt & pepper',noise);
        %Ket Augmentation
        T = CastImageAsKet(T,Nway,I1,J1);
        Y = CastImageAsKet(Y,Nway,I1,J1);
        % Omega
        P = round((1-mr)*prod(Nway));
        Known = randsample(prod(Nway),P);
        [Known,~] = sort(Known);
        Omega = zeros(n1,n2,n3);
        Omega(Known) = 1;
        Omega = logical(Omega);
        %% RTC
        [X_rtc, N_rtc, Show, Observed] = RTC(T,Y, Known, maxIter, epsilon,mr,noise);
        X_rtc=CastKet2Image(X_rtc,n1,n2,I1,J1);
        N_rtc=CastKet2Image(N_rtc,n1,n2,I1,J1);
        Observed=CastKet2Image(Observed,n1,n2,I1,J1);
        %% Average RTC
        [X_rtc2, N_rtc2, Show, Observed] = RTC2(T,Y, Known, maxIter, epsilon,mr,noise);
        X_rtc2=CastKet2Image(X_rtc2,n1,n2,I1,J1);
        N_rtc2=CastKet2Image(N_rtc2,n1,n2,I1,J1);
        Observed=CastKet2Image(Observed,n1,n2,I1,J1);
        T=CastKet2Image(T,256,256,I1,J1);
        Y=CastKet2Image(Y,256,256,I1,J1);
        str = strcat("F:\PIC\Lena3\",num2str(100*mr),"mr",num2str(100*noise),"noise");
        if ~exist(str,'file')
            mkdir(str)
        end
        imwrite(uint8(T),strcat(str,'\Original','.jpg'));
        imwrite(uint8(Y),strcat(str,'\Corrupted','.jpg'));
        imwrite(uint8(Observed),strcat(str,'\Observed','.jpg'));
        imwrite(uint8(X_rtc),strcat(str,'\X_rtc','.jpg'));
        imwrite(uint8(N_rtc),strcat(str,'\N_rtc','.jpg'));
        imwrite(uint8(X_rtc2),strcat(str,'\X_rtc2','.jpg'));
        imwrite(uint8(N_rtc2),strcat(str,'\N_rtc2','.jpg'));

        [p_rtc, m_rtc] = Mypsnr(X_rtc, T);
        [s_rtc, ~] = ssim(X_rtc,T);
        [p_rtc2, m_rtc2] = Mypsnr(X_rtc2, T);
        [s_rtc2, ~] = ssim(X_rtc2,T);
        MSEv=[m_rtc,m_rtc2];
        SSIMv=[s_rtc,s_rtc2];
        PSNRv=[p_rtc,p_rtc2];
        save(strcat(str,'\PSNR','.mat'),'PSNRv');
        save(strcat(str,'\MSE','.mat'),'MSEv');
        save(strcat(str,'\SSIM','.mat'),'SSIMv');
    end
end


















