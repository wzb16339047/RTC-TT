function [X] = CastVideoAsKet2(M,Nway,I,J,K)

    for i1 = 1: Nway(1)
        for i2 = 1: Nway(2)
            for i3 = 1: Nway(3)
                
                
                for i4 = 1: Nway(4)
                    for i5 = 1: Nway(5)
                        for i6 = 1: Nway(6)
                            
                            
                            for i7 = 1: Nway(7)
                                for i8 = 1: Nway(8)
                                    for i9 = 1: Nway(9)
 
                            
                                        for i10 = 1: Nway(10)
                                            i = i10+(i1-1)*I(2)*I(3)*I(4)+(i4-1)*I(3)*I(4)+(i7-1)*I(4);
                                            for i11 = 1: Nway(11)
                                                j = i11+(i2-1)*J(2)*J(3)*J(4)+(i5-1)*J(3)*J(4)+(i8-1)*J(4);
                                                for i12 = 1: Nway(12)
                                                    k = i12+(i3-1)*K(2)*K(3)*K(4)+(i6-1)*K(3)*K(4)+(i9-1)*K(4);
                                                    X(i1,i2,i3,i4,i5,i6,i7,i8,i9,i10,i11,i12,:) = M(i,j,:,k);
                                                end
                                            end
                                        end
                                        
                                        
                                    end
                                end
                            end
                            
                            
                        end
                    end
                end
                
                
            end
        end
    end
end


