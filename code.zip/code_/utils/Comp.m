clc;
addpath(genpath(cd))
clear
addpath("../RTC")
addpath("C:\Users\Administrator\Desktop\Comparsion\Others\private")
%% Examples for testing the low-rank tensor models
% For detailed description of the sparse models, please refer to the Manual.
opts.mu = 1e-6;
opts.rho = 1.1;
opts.max_iter = 1000;
opts.DEBUG = 1;
% A = load('Original.mat');
% T = A.T;
% Nway = [4 4 4 4 4 4 4 4 3 4 4 2];
% I = [4 4 4 4];
% J = [4 4 4 4];
% K = [4 4 3 2];


A = load('MRI_144.mat');
T = A.MRI_144;

% Nway = [4 4 4 4 4 4 4 4 3];     % 9th-order dimensions for KA
% n1 = 256;
% n2 = 256;
% n3 = 3;
% I1 = 2; J1 = 2;  


% for i = 1:96
%     MM(:,:,i) = T(:,:,i);
% end
% T = MM;
Nway = [4 4 4 4 4 4 3 4 3 3 3 3];
I = [4 4 3 3];
J = [4 4 4 3];
K = [4 4 3 3];
[n1 n2 n3] = size(T);

% A = load('samson_1.mat');
% T = A.V;
% 
% 
% T = reshape(T',[95 95 156]);
% for i = 1:30
%     MM(1:90,1:90,i) = T(1:90,1:90,i);
% end
% T = MM;
% Nway = [3 3 3 3 3 2 2 2 5 5 5 1];
% I = [3 3 2 5];
% J = [3 3 2 5];
% K = [3 2 5 1];
% [n1 n2 n3] = size(T);
% 
% videoSequence = 'suzie_qcif.yuv';

% n1  = 176;
% n2 = 144;
% n3 = 150;
% [T,U,V] = yuvRead(videoSequence, n1, n2 ,n3); % T=double(Y(17:272,49:304,:));
% T =double(T)./255;
% size(T)
% Nway = [4 4 5 4 4 5 11 9 6]
% Initial parameters
% Nway = [4 4 4 4 4 4 3 3 3 3 3 3];
% I = [4 4 3 3];
% J = [4 4 3 3];
% K = [4 4 3 3];
% [n1 n2 n3] = size(T);

maxIter=500;
epsilon = 1e-5;

for noise = 0.1
    for mr = 0.5
        %Ket Augmentation
        Y=imnoise(T,'salt & pepper',noise);
%         T =  CastImageAsKet(T,Nway,I1,J1);
%         Y = CastImageAsKet(Y,Nway,I1,J1);
        % Omega
        P = round((1-mr)*prod(Nway));
        Known = randsample(prod(Nway),P);
        [Known,~] = sort(Known);
        Omega = zeros(n1,n2,n3);
        Omega(Known) = 1;
        Omega = logical(Omega);
        Observed = Y;
        Observed(logical(1-Omega)) = mean(Y(Omega));
%         Omega = logical(Omega);
%          %% RTC
%         [X_rtc, N_rtc, Show, Observed] = TRPCA_Omega2(T,Y, Known, maxIter, epsilon,mr,noise);
%         X_rtc=CastKet2Image(X_rtc,n1,n2,I1,J1);
%         N_rtc=CastKet2Image(N_rtc,n1,n2,I1,J1);
%         Observed=CastKet2Image(Observed,n1,n2,I1,J1);
%         Show = CastKet2Image(Show,n1,n2,I1,J1);
%         T=CastKet2Image(T,n1,n2,I1,J1);
%         Y=CastKet2Image(Y,n1,n2,I1,J1);
%         psnr(X_rtc,T)
        %% trpca_tnn2
         maxP = max(abs(T(:)));
%         lambda = 1/sqrt(max(n1,n2)*n3);
%         [X_trpcatnn2,N_trpcatnn2] = trpca_tnn2(Y,lambda,opts,Known);
%         X_trpcatnn2 = max(X_trpcatnn2,0);
%         X_trpcatnn2= min(X_trpcatnn2,maxP);

       %% TRPCA_SNN2
%         alpha = sqrt([max(n1,n2*n3), max(n2,n1*n3), max(n3,n1*n2)])./3;
         alpha = [30 35 30];
        [X_trpcasnn2,N_trpcasnn2,err_trpcasnn2,iter_trpcasnn2] = trpca_snn(Observed,alpha,opts);
        X_trpcasnn2 = max(X_trpcasnn2,0);
        X_trpcasnn2= min(X_trpcasnn2,maxP);
        psnr(X_trpcasnn2,T)
        figure(1);
        imshow(X_trpcasnn2(:,:,53));
        figure(2);
        imshow(N_trpcasnn2(:,:,53));
        %% Output
%         str = strcat("F:\PIC\Urban_4\",num2str(100*mr),"mr",num2str(100*noise),"noise");
%         if ~exist(str,'file')
%             mkdir(str)
%         end
%         save(strcat(str,'\Original','.mat'),'T');
%         save(strcat(str,'\Corrupted','.mat'),'Y');
%         save(strcat(str,'\Observed','.mat'),'Observed');
%         save(strcat(str,'\Show','.mat'),'Show');
%         save(strcat(str,'\X_rtc','.mat'),'X_rtc');
%         save(strcat(str,'\N_rtc','.mat'),'N_rtc');
%         save(strcat(str,'\X_trpcatnn2','.mat'),'X_trpcatnn2');
%         save(strcat(str,'\N_trpcatnn2','.mat'),'N_trpcatnn2');
%         save(strcat(str,'\X_trpcasnn2','.mat'),'X_trpcasnn2');
%         save(strcat(str,'\N_trpcasnn2','.mat'),'N_trpcasnn2');
%         [p_rtc, m_rtc] = psnr(X_rtc, T);
%         [s_rtc, ~] = ssim(X_rtc,T);
%         [p_trpcatnn2, m_trpcatnn2] = psnr(X_trpcatnn2, T);
%         [s_trpcatnn2, ~] = ssim(X_trpcatnn2,T);
%         [p_trpcasnn2, m_trpcasnn2] = psnr(X_trpcasnn2, T);
%         [s_trpcasnn2, ~] = ssim(X_trpcasnn2,T);
%         MSEv=[m_rtc,m_trpcasnn2,m_trpcatnn2];
%         SSIMv=[s_rtc,s_trpcasnn2,s_trpcatnn2];
%         PSNRv=[p_rtc,p_trpcasnn2,p_trpcatnn2];
%         save(strcat(str,'\PSNR','.mat'),'PSNRv');
%         save(strcat(str,'\MSE','.mat'),'MSEv');
%         save(strcat(str,'\SSIM','.mat'),'SSIMv');
    end
end
















