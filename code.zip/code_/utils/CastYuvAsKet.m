function [X] = CastYuvAsKet(M,Nway,I,J,K)

                
                
                for i1 = 1: Nway(1)
                    for i2 = 1: Nway(2)
                        for i3 = 1: Nway(3)
                            
                            
                            for i4 = 1: Nway(4)
                                for i5 = 1: Nway(5)
                                    for i6 = 1: Nway(6)
 
                            
                                        for i7 = 1: Nway(7)
                                            i = i7+(i1-1)*I(2)*I(3)+(i4-1)*I(3);
                                            for i8 = 1: Nway(8)
                                                j = i8+(i2-1)*J(2)*J(3)+(i5-1)*J(3);
                                                for i9 = 1: Nway(9)
                                                    k = i9+(i3-1)*K(2)*K(3)+(i6-1)*K(3);
                                                    X(i1,i2,i3,i4,i5,i6,i7,i8,i9,:) = M(i,j,k,:);
                                                end
                                            end
                                        end
                                        
                                        
                                    end
                                end
                            end
                            
                            
                        end
                    end
                end
                
                
end

