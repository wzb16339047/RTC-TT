clc;
addpath(genpath(cd))
clear
addpath('./RTC')
%% Examples for testing the low-rank tensor models
% For detailed description of the sparse models, please refer to the Manual.
opts.mu = 1e-6;
opts.rho = 1.1;
opts.max_iter = 1000;
opts.DEBUG = 1;
videoSequence = 'suzie_qcif.yuv';

n1  = 176;
n2 = 144;
n3 = 150;

% Read the video sequence
[T,U,V] = yuvRead(videoSequence, n1, n2 ,n3); % T=double(Y(17:272,49:304,:));
T =double(T)./255;
% Initial parameters
Nway = [4 4 5 4 4 5 9 11 6];
I = [4 4 9];
J = [4 4 11];
K = [5 5 6];



maxIter=1000;
epsilon = 1e-5;

for noise = 0.05:0.05:0.3
    for mr = 0.1:0.1:0.6
        %Ket Augmentation
        Y=imnoise(T,'salt & pepper',noise);
        T = CastYuvAsKet(T,Nway,I,J,K);
        Y = CastYuvAsKet(Y,Nway,I,J,K);
       
        % Omega
        P = round((1-mr)*prod(Nway));
        Known = randsample(prod(Nway),P);
        [Known,~] = sort(Known);
        Omega = zeros(n1,n2,n3);
        Omega(Known) = 1;
        Omega = logical(Omega);
        %% RTC

        [X_rtc, N_rtc, Observed, errList_rtc] = TRPCA_Omega2(T,Y, Known, maxIter, epsilon,mr,noise);
        X_rtc=CastKet2Yuv(X_rtc,Nway,I,J,K);
        N_rtc=CastKet2Yuv(N_rtc,Nway,I,J,K);
        Observed=CastKet2Yuv(Observed,Nway,I,J,K);
        %% SiLRTC-TT
        [X_silrtctt, N_silrtctt,errList_silrtctt] = SiLRTCTT(T,Y, Known, maxIter, epsilon);
        X_silrtctt=CastKet2Yuv(X_silrtctt,Nway,I,J,K);
        N_silrtctt=CastKet2Yuv(N_silrtctt,Nway,I,J,K);
        %% TMac-TT
        [Out,~] = TensorCompletion(Y,Known,mr); 
        X_tmactt=CastKet2Yuv(Out.MS,Nway,I,J,K);
        T=CastKet2Yuv(T,Nway,I,J,K);
        Y=CastKet2Yuv(Y,Nway,I,J,K);
        N_tmactt=Y-X_tmactt;
        %% SiLRTC
        alpha = ones(1, ndims(T));
        alpha = alpha / sum(alpha);
        beta = 0.1*ones(1, ndims(T));
        [X_silrtc,errList_silrtc] = SiLRTC(T,Y, Omega, alpha, beta, maxIter, epsilon);
        N_silrtc = Y-X_silrtc;
        %% low-rank tensor completion based on tensor nuclear norm minimization (lrtc_tnn)
        [X_lrtctnn,obj_lrtctnn,err_lrtctnn,iter_lrtctnn] = lrtc_tnn(Y,Omega,opts);
        N_lrtctnn=Y-X_lrtctnn;
        %% trpca_tnn
        maxP = max(abs(T(:)));
        lambda = 1/sqrt(max(n1,n2)*n3);
        [X_trpcatnn,N_trpcatnn,err_trpcatnn,iter_trpcatnn] = trpca_tnn(Observed,lambda,opts);
        X_trpcatnn = max(X_trpcatnn,0);
        X_trpcatnn= min(X_trpcatnn,maxP);
        psnr(X_trpcatnn,T)
        %% Tensor RRPCA based on sum of nuclear norm minimization (rpca_snn)
        lambda =sqrt([max(n1,n2*n3), max(n2,n1*n3), max(n3,n1*n2)])./3;
        [X_trpcasnn,N_trpcasnn,err_trpcasnn,iter_trpcasnn] = trpca_snn(Observed,lambda,opts);
        %% Output
        str = strcat('/home/inplus/Wzb/Comparsion/Suize/',num2str(100*mr),'mr',num2str(100*noise),'noise');
        if ~exist(str,'file')
            mkdir(str)
        end
        save(strcat(str,'/Original','.mat'),'T');
        save(strcat(str,'/Corrupted','.mat'),'Y');
        save(strcat(str,'/Observed','.mat'),'Observed');
        save(strcat(str,'/X_rtc','.mat'),'X_rtc');
        save(strcat(str,'/N_rtc','.mat'),'N_rtc');
        save(strcat(str,'/X_silrtc','.mat'),'X_silrtc');
        save(strcat(str,'/N_silrtc','.mat'),'N_silrtc');
        save(strcat(str,'/X_silrtctt','.mat'),'X_silrtctt');
        save(strcat(str,'/N_silrtctt','.mat'),'N_silrtctt');
        save(strcat(str,'/X_tamctt','.mat'),'X_tmactt');
        save(strcat(str,'/N_tmactt','.mat'),'N_tmactt');
        save(strcat(str,'/X_lrtctnn','.mat'),'X_lrtctnn');
        save(strcat(str,'/N_lrtctnn','.mat'),'N_lrtctnn');
        save(strcat(str,'/X_trpcatnn','.mat'),'X_trpcatnn');
        save(strcat(str,'/N_trpcatnn','.mat'),'N_trpcatnn');
        save(strcat(str,'/X_trpcasnn','.mat'),'X_trpcasnn');
        save(strcat(str,'/N_trpcasnn','.mat'),'N_trpcasnn');
        [p_rtc, m_rtc] = psnr(X_rtc, T);
%         [s_rtc, ~] = ssim(X_rtc,T);
        [p_silrtctt, m_silrtctt] = psnr(X_silrtctt, T);
%         [s_silrtctt, ~] = ssim(X_silrtctt,T);
        [p_tmactt, m_tmactt] = psnr(X_tmactt, T);
%         [s_tmactt, ~] = ssim(X_tmactt,T);
        [p_silrtc, m_silrtc] = psnr(X_silrtc, T);
%         [s_silrtc, ~] = ssim(X_silrtc,T);
        [p_lrtctnn, m_lrtctnn] = psnr(X_lrtctnn, T);
%         [s_lrtctnn, ~] = ssim(X_lrtctnn,T);
        [p_trpcatnn, m_trpcatnn] = psnr(X_trpcatnn, T);
%         [s_trpcatnn, ~] = ssim(X_trpcatnn,T);
        [p_trpcasnn, m_trpcasnn] = psnr(X_trpcasnn, T);
%         [s_trpcasnn, ~] = ssim(X_trpcasnn,T);
        MSEv=[m_rtc,m_silrtctt,m_tmactt,m_silrtc,m_lrtctnn,m_trpcasnn,m_trpcatnn];
%         SSIMv=[s_rtc,s_silrtctt,s_tmactt,s_silrtc,s_lrtctnn,s_trpcasnn,s_trpcatnn];
        PSNRv=[p_rtc,p_silrtctt,p_tmactt,p_silrtc,p_lrtctnn,p_trpcasnn,p_trpcatnn];
        save(strcat(str,'/PSNR','.mat'),'PSNRv');
        save(strcat(str,'/MSE','.mat'),'MSEv');
%         save(strcat(str,'/SSIM','.mat'),'SSIMv');
%         fprintf('The MSE value is RTC:%0.4f. SILRTCTT:%0.4f TMACTT:%0.4f SILRTC:%0.4f LRTCTNN:%0.4f TRPCA_SNN:%0.4f TRPCA_TNN:%0.4f\n', m_rtc,m_silrtctt,m_tmactt,m_silrtc,m_lrtctnn,m_trpcasnn,m_trpcatnn);
%         fprintf('The SSIM value is RTC:%0.4f. SILRTCTT:%0.4f TMACTT:%0.4f SILRTC:%0.4f LRTCTNN:%0.4f TRPCA_SNN:%0.4f TRPCA_TNN:%0.4f\n',s_rtc,s_silrtctt,s_tmactt,s_silrtc,s_lrtctnn,s_trpcasnn,s_trpcatnn);
%         fprintf('The Peak-SNR value is RTC:%0.4f. SILRTCTT:%0.4f TMACTT:%0.4f SILRTC:%0.4f LRTCTNN:%0.4f TRPCA_SNN:%0.4f TRPCA_TNN:%0.4f\n', p_rtc,p_silrtctt,p_tmactt,p_silrtc,p_lrtctnn,p_trpcasnn,p_trpcatnn);
    end
end
















