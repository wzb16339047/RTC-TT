% Nway = [6 8 5 8 8 5 5 5 4 3];
% I = [6 8 5];
% J = [8 8 5];
% K = [5 5 4];

% Nway = [4 5 5 4 4 5 4 4 4 4 4 3 3];
% I = [4 4 4 4];
% J = [5 4 4 4];
% K = [5 5 4 3];

Nway = [4 5 5 4 4 5 4 4 3 2 2 2 3];
I = [4 4 4 2];
J = [5 4 4 2];
K = [5 5 3 2];

load('Hall.mat');
Tvideo = double(P);
Tvideo = CastVideoAsKet2(Tvideo,Nway,I,J,K);
Y = Tvideo;
maxIter=500;
epsilon = 1e-5;


for mr = 0
    noise = 0.1;
    
    P = round((1-mr)*prod(Nway));
    Known = randsample(prod(Nway),P);
    [Known,~] = sort(Known);
    [X_rtc, N_rtc, Observed, Show] = TRPCA_Omega(Tvideo,Y, Known, maxIter, epsilon,mr,noise);
%     [X_rtc2, N_rtc2, Observed2, Show2] = TRPCA_Omega2(Tvideo,Y, Known, maxIter, epsilon,mr,noise);
    X_rtc = CastKet2Video2(X_rtc,Nway,I,J,K);
    N_rtc = CastKet2Video2(N_rtc,Nway,I,J,K);
%     X_rtc2 = CastKet2Video(X_rtc2,Nway,I,J,K);
%     N_rtc2 = CastKet2Video(N_rtc2,Nway,I,J,K);
    Observed = CastKet2Video2(Observed,Nway,I,J,K);
    Show = CastKet2Video2(Show,Nway,I,J,K);
%     Observed2 = CastKet2Video(Observed2,Nway,I,J,K);
%     Show2 = CastKet2Video(Show2,Nway,I,J,K);

    str = strcat("F:\PIC\Hall\",num2str(100*mr),"mr");
    if ~exist(str,'file')
        mkdir(str)
    end
    save(strcat(str,'\X_rtc','.mat'),'X_rtc');
    save(strcat(str,'\N_rtc','.mat'),'N_rtc');
    save(strcat(str,'\Observed','.mat'),'Observed');
    save(strcat(str,'\Show','.mat'),'Show');
%     save(strcat(str,'\X_rtc2','.mat'),'X_rtc2');
%     save(strcat(str,'\N_rtc2','.mat'),'N_rtc2');
%     save(strcat(str,'\Observed2','.mat'),'Observed2');
%     save(strcat(str,'\Show2','.mat'),'Show2');
end