clc;
addpath(genpath(cd))
clear
addpath("../RTC")
addpath("C:\Users\Administrator\Desktop\Comparsion\Others\private")
%% Examples for testing the low-rank tensor models
% For detailed description of the sparse models, please refer to the Manual.
opts.mu = 1e-6;
opts.rho = 1.1;
opts.max_iter = 1000;
opts.DEBUG = 1;
% %VIDEO
% videoSequence = 'news_cif.yuv';
% width  = 352;
% height = 288;
% nFrame = 300;
% % Read the video sequence
% [Y,U,V] = yuvRead(videoSequence, width, height ,nFrame); 
% T=double(Y(17:272,49:304,:));
% Initial parameters
Nway = [5 5 2 19 19 2 1 1 3 1 1 13];
I = [5 19 1 1];
J = [5 19 1 1];
K = [2 2 3 13];
A = load('samson_1.mat');
T = A.V;
T = reshape(T',[95 95 156]);

n1 = 95;
n2 = 95;
n3 = 156;

maxIter=500;
epsilon = 1e-5;

for noise = 0.1
    for mr = 0.4
        %Ket Augmentation
        Y=imnoise(T,'salt & pepper',noise);
        T = CastHighImageAsKet(T,Nway,I,J,K);
        Y = CastHighImageAsKet(Y,Nway,I,J,K);
       
        % Omega
        P = round((1-mr)*prod(Nway));
        Known = randsample(prod(Nway),P);
        [Known,~] = sort(Known);
        Omega = zeros(n1,n2,n3);
        Omega(Known) = 1;
        Omega = logical(Omega);
        %% RTC

        [X_rtc, N_rtc, Show, Observed] = RTC(T,Y, Known, maxIter, epsilon,mr,noise);
        X_rtc=CastKet2HighImage(X_rtc,Nway,I,J,K);
        N_rtc=CastKet2HighImage(N_rtc,Nway,I,J,K);
        Observed=CastKet2HighImage(Observed,Nway,I,J,K);
        Show = CastKet2HighImage(Show,Nway,I,J,K);
        %% SiLRTC-TT
        [X_silrtctt, N_silrtctt,errList_silrtctt] = SiLRTCTT(T,Y, Known, maxIter, epsilon);
        X_silrtctt=CastKet2HighImage(X_silrtctt,Nway,I,J,K);
        N_silrtctt=CastKet2HighImage(N_silrtctt,Nway,I,J,K);
        %% TMac-TT
        [Out,~] = TensorCompletion(Y,Known,mr); 
        X_tmactt=CastKet2HighImage(Out.MS,Nway,I,J,K);
        T=CastKet2HighImage(T,Nway,I,J,K);
        Y=CastKet2HighImage(Y,Nway,I,J,K);
        N_tmactt=Y-X_tmactt;
        %% SiLRTC
        alpha = ones(1, ndims(T));
        alpha = alpha / sum(alpha);
        beta = 0.1*ones(1, ndims(T));
        [X_silrtc,errList_silrtc] = SiLRTC(T,Y, Omega, alpha, beta, maxIter, epsilon);
        N_silrtc = Y-X_silrtc;
%         %% low-rank tensor completion based on tensor nuclear norm minimization (lrtc_tnn)
%         [X_lrtctnn,obj_lrtctnn,err_lrtctnn,iter_lrtctnn] = lrtc_tnn(Y,Omega,opts);
%         N_lrtctnn=Y-X_lrtctnn;
        %% trpca_tnn
        maxP = max(abs(T(:)));
        lambda = 1/sqrt(max(n1,n2)*n3);
        [X_trpcatnn,N_trpcatnn,err_trpcatnn,iter_trpcatnn] = trpca_tnn(Observed,lambda,opts);
        X_trpcatnn = max(X_trpcatnn,0);
        X_trpcatnn= min(X_trpcatnn,maxP);
        psnr(X_trpcatnn,T)
        %% trpca_tnn2
        [X_trpcatnn2,N_trpcatnn2] = trpca_tnn2(Y,lambda,opts,Known);
        X_trpcatnn2 = max(X_trpcatnn2,0);
        X_trpcatnn2= min(X_trpcatnn2,maxP);
        %% Tensor RRPCA based on sum of nuclear norm minimization (rpca_snn)
        alpha = sqrt([max(n1,n2*n3), max(n2,n1*n3), max(n3,n1*n2)])./3;
        [X_trpcasnn,N_trpcasnn,err_trpcasnn,iter_trpcasnn] = trpca_snn(Observed,alpha,opts);
       %% TRPCA_SNN2
        [X_trpcasnn2,N_trpcasnn2,err_trpcasnn2,iter_trpcasnn2] = trpca_snn2(Y,alpha,opts,Known);
        X_trpcasnn2 = max(X_trpcasnn2,0);
        X_trpcasnn2= min(X_trpcasnn2,maxP);
        %% Output
        str = strcat("F:\PIC\Samson\",num2str(100*mr),"mr",num2str(100*noise),"noise");
        if ~exist(str,'file')
            mkdir(str)
        end
        save(strcat(str,'\Original','.mat'),'T');
        save(strcat(str,'\Corrupted','.mat'),'Y');
        save(strcat(str,'\Observed','.mat'),'Observed');
        save(strcat(str,'\Show','.mat'),'Show');
        save(strcat(str,'\X_rtc','.mat'),'X_rtc');
        save(strcat(str,'\N_rtc','.mat'),'N_rtc');
        save(strcat(str,'\X_silrtc','.mat'),'X_silrtc');
        save(strcat(str,'\N_silrtc','.mat'),'N_silrtc');
        save(strcat(str,'\X_silrtctt','.mat'),'X_silrtctt');
        save(strcat(str,'\N_silrtctt','.mat'),'N_silrtctt');
        save(strcat(str,'\X_tamctt','.mat'),'X_tmactt');
        save(strcat(str,'\N_tmactt','.mat'),'N_tmactt');
        save(strcat(str,'\X_trpcatnn','.mat'),'X_trpcatnn');
        save(strcat(str,'\N_trpcatnn','.mat'),'N_trpcatnn');
        save(strcat(str,'\X_trpcasnn','.mat'),'X_trpcasnn');
        save(strcat(str,'\N_trpcasnn','.mat'),'N_trpcasnn');
        save(strcat(str,'\X_trpcatnn2','.mat'),'X_trpcatnn2');
        save(strcat(str,'\N_trpcatnn2','.mat'),'N_trpcatnn2');
        save(strcat(str,'\X_trpcasnn2','.mat'),'X_trpcasnn2');
        save(strcat(str,'\N_trpcasnn2','.mat'),'N_trpcasnn2');
        [p_rtc, m_rtc] = psnr(X_rtc, T);
        [s_rtc, ~] = ssim(X_rtc,T);
        [p_silrtctt, m_silrtctt] = psnr(X_silrtctt, T);
        [s_silrtctt, ~] = ssim(X_silrtctt,T);
        [p_tmactt, m_tmactt] = psnr(X_tmactt, T);
        [s_tmactt, ~] = ssim(X_tmactt,T);
        [p_silrtc, m_silrtc] = psnr(X_silrtc, T);
        [s_silrtc, ~] = ssim(X_silrtc,T);
        [p_trpcatnn2, m_trpcatnn2] = psnr(X_trpcatnn2, T);
        [s_trpcatnn2, ~] = ssim(X_trpcatnn2,T);
        [p_trpcatnn, m_trpcatnn] = psnr(X_trpcatnn, T);
        [s_trpcatnn, ~] = ssim(X_trpcatnn,T);
        [p_trpcasnn, m_trpcasnn] = psnr(X_trpcasnn, T);
        [s_trpcasnn, ~] = ssim(X_trpcasnn,T);
        [p_trpcasnn2, m_trpcasnn2] = psnr(X_trpcasnn2, T);
        [s_trpcasnn2, ~] = ssim(X_trpcasnn2,T);
        MSEv=[m_rtc,m_silrtctt,m_tmactt,m_silrtc,m_trpcasnn,m_trpcatnn,m_trpcasnn2,m_trpcatnn2];
        SSIMv=[s_rtc,s_silrtctt,s_tmactt,s_silrtc,s_trpcasnn,s_trpcatnn,s_trpcasnn2,s_trpcatnn2];
        PSNRv=[p_rtc,p_silrtctt,p_tmactt,p_silrtc,p_trpcasnn,p_trpcatnn,p_trpcasnn2,p_trpcatnn2];
        save(strcat(str,'\PSNR','.mat'),'PSNRv');
        save(strcat(str,'\MSE','.mat'),'MSEv');
        save(strcat(str,'\SSIM','.mat'),'SSIMv');
        fprintf('The MSE value is RTC:%0.4f. SILRTCTT:%0.4f TMACTT:%0.4f SILRTC:%0.4f  TRPCA_SNN:%0.4f TRPCA_SNN2:%0.4f TRPCA_TNN:%0.4f TRPCA_TNN2:%0.4f\n', m_rtc,m_silrtctt,m_tmactt,m_silrtc,m_trpcasnn,m_trpcasnn2,m_trpcatnn,m_trpcatnn2);
        fprintf('The SSIM value is RTC:%0.4f. SILRTCTT:%0.4f TMACTT:%0.4f SILRTC:%0.4f  TRPCA_SNN:%0.4f TRPCA_SNN2:%0.4f TRPCA_TNN:%0.4f TRPCA_TNN2:%0.4f\n',s_rtc,s_silrtctt,s_tmactt,s_silrtc,s_trpcasnn,s_trpcasnn2,s_trpcatnn,s_trpcatnn2);
        fprintf('The Peak-SNR value is RTC:%0.4f. SILRTCTT:%0.4f TMACTT:%0.4f SILRTC:%0.4f  TRPCA_SNN:%0.4f TRPCA_SNN2:%0.4f TRPCA_TNN:%0.4f TRPCA_TNN2:%0.4f\n', p_rtc,p_silrtctt,p_tmactt,p_silrtc,p_trpcasnn,p_trpcasnn2,p_trpcatnn,p_trpcatnn2);
     end
end
















