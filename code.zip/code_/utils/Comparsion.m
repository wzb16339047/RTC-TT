addpath(genpath(cd))
clear
addpath("../RTC")
%% Examples for testing the low-rank tensor models
% For detailed description of the sparse models, please refer to the Manual.
opts.mu = 1e-6;
opts.rho = 1.1;
opts.max_iter = 1000;
opts.DEBUG = 1;

% Initial parameters
Nway = [4 4 4 4 4 4 4 4 3];     % 9th-order dimensions for KA
n1 = 256;
n2 = 256;
n3 = 3;
I1 = 2; J1 = 2;                 % KA parameters
maxIter=500;
epsilon = 1e-5;
T = double(imread('lena.bmp'));                                           % ��ɫ��[0,0,0]��ɫ��[255,255,255]��ɫ��
loc = int32([0 0;0 190;0 100]); 
Y = insertText(T,loc,"ABCDEFG",'FontSize',50, 'BoxOpacity',0);
T=T./255;
Y=Y./255;
% XX = step( textInserter, A, TemText, loc );
% Y = imnoise(Y,'salt & pepper',noise);
for noise = 0.1
        Y = imnoise(Y,'salt & pepper',noise);
        
        %Ket Augmentation
        T = CastImageAsKet(T,Nway,I1,J1);
        Y = CastImageAsKet(Y,Nway,I1,J1);
        
        Known=logical(T==Y);
        mr = 1-sum(Known(:))/prod(Nway)
        % Omega
%         P = round((1-mr)*prod(Nway));
%         Known = randsample(prod(Nway),P);
%         [Known,~] = sort(Known);

        %% RTC
        [X_rtc, N_rtc, Show, Observed, errList,psnrList] = RTC_alpha(T,Y, Known, maxIter, epsilon, mr, noise,1.1);
        X_rtc=CastKet2Image(X_rtc,n1,n2,I1,J1);
        N_rtc=CastKet2Image(N_rtc,n1,n2,I1,J1);
        Observed=CastKet2Image(Observed,n1,n2,I1,J1);
        Show=CastKet2Image(Show,n1,n2,I1,J1);
        %% SiLRTC-TT
        [X_silrtctt, N_silrtctt,errList_silrtctt] = SiLRTCTT(T,Y, Known, maxIter, epsilon);
        X_silrtctt=CastKet2Image(X_silrtctt,n1,n2,I1,J1);
        N_silrtctt=CastKet2Image(N_silrtctt,n1,n2,I1,J1);
        %% TMac-TT
        [Out,~] = TensorCompletion(Y,Known,mr); 
        X_tmactt=CastKet2Image(Out.MS,n1,n2,I1,J1);
        T=CastKet2Image(T,256,256,I1,J1);
        Y=CastKet2Image(Y,256,256,I1,J1);
        N_tmactt=Y-X_tmactt;
        %% SiLRTC
        Omega = zeros(n1,n2,n3);
        Known =CastKet2Image(Known,256,256,I1,J1);
        Omega(logical(Known)) = 1;
        Omega = logical(Omega);
        alpha = ones(1, ndims(T));
        alpha = alpha / sum(alpha);
        beta = 0.1*ones(1, ndims(T));
        [X_silrtc,errList_silrtc] = SiLRTC(T,Y, Omega, alpha, beta, maxIter, epsilon);
        N_silrtc = Y-X_silrtc;
%         %% low-rank tensor completion based on tensor nuclear norm minimization (lrtc_tnn)
%         [X_lrtctnn,obj_lrtctnn,err_lrtctnn,iter_lrtctnn] = lrtc_tnn(Y,Omega,opts);
%         N_lrtctnn=Y-X_lrtctnn;
        %% trpca_tnn
        maxP = max(abs(T(:)));
        lambda = 1/sqrt(max(n1,n2)*n3);
        [X_trpcatnn,N_trpcatnn,err_trpcatnn,iter_trpcatnn] = trpca_tnn(Observed,lambda,opts);
        X_trpcatnn = max(X_trpcatnn,0);
        X_trpcatnn= min(X_trpcatnn,maxP);
        %% trpca_tnn2
        [X_trpcatnn2,N_trpcatnn2] = trpca_tnn2(Y,lambda,opts,Known);
        X_trpcatnn2 = max(X_trpcatnn2,0);
        X_trpcatnn2= min(X_trpcatnn2,maxP);
        %% Tensor RRPCA based on sum of nuclear norm minimization (rpca_snn)
         alpha = sqrt([max(n1,n2*n3), max(n2,n1*n3), max(n3,n1*n2)])./3;
        [X_trpcasnn,N_trpcasnn,err_trpcasnn,iter_trpcasnn] = trpca_snn(Observed,alpha,opts);
        X_trpcasnn = max(X_trpcasnn,0);
        X_trpcasnn= min(X_trpcasnn,maxP);
        %% TRPCA_SNN2
        [X_trpcasnn2,N_trpcasnn2,err_trpcasnn2,iter_trpcasnn2] = trpca_snn2(Y,alpha,opts,Known);
        X_trpcasnn2 = max(X_trpcasnn2,0);
        X_trpcasnn2= min(X_trpcasnn2,maxP);
%         K =T-Observed;
%         cc =1;
%         for i=1:256*256*3
%             if(K(i)~=0)
%                 pos(cc)=i;
%                 cc = cc+1;
%             end
%         end
%         Omega2 = zeros(256,256,3);
%         Omega2(pos)=1;
%         Observed2=Observed;
%         Omega2=logical(Omega2);
%         Observed2(Omega2) = mean(Y(Omega));
        
        str = strcat("F:\PIC\text_lena\",num2str(100*mr),"mr",num2str(100*noise),"noise");
        if ~exist(str,'file')
            mkdir(str)
        end
        imwrite(T,strcat(str,'\Original','.jpg'));
        imwrite(Y,strcat(str,'\Corrupted','.jpg'));
        imwrite(Observed,strcat(str,'\Observed','.jpg'));
        imwrite(Show,strcat(str,'\Show','.jpg'));
        imwrite(X_rtc,strcat(str,'\X_rtc','.jpg'));
        imwrite(N_rtc,strcat(str,'\N_rtc','.jpg'));
        imwrite(X_silrtc,strcat(str,'\X_silrtc','.jpg'));
        imwrite(N_silrtc,strcat(str,'\N_silrtc','.jpg'));
        imwrite(X_silrtctt,strcat(str,'\X_silrtctt','.jpg'));
        imwrite(N_silrtctt,strcat(str,'\N_silrtctt','.jpg'));
        imwrite(X_tmactt,strcat(str,'\X_tamctt','.jpg'));
        imwrite(N_tmactt,strcat(str,'\N_tmactt','.jpg'));
%         imwrite(X_lrtctnn,strcat(str,'\X_lrtctnn','.jpg'));
%         imwrite(N_lrtctnn,strcat(str,'\N_lrtctnn','.jpg'));
        imwrite(X_trpcatnn,strcat(str,'\X_trpcatnn','.jpg'));
        imwrite(N_trpcatnn,strcat(str,'\N_trpcatnn','.jpg'));
        imwrite(X_trpcatnn2,strcat(str,'\X_trpcatnn2','.jpg'));
        imwrite(N_trpcatnn2,strcat(str,'\N_trpcatnn2','.jpg'));
        imwrite(X_trpcasnn,strcat(str,'\X_trpcasnn','.jpg'));
        imwrite(N_trpcasnn,strcat(str,'\N_trpcasnn','.jpg'));
        imwrite(X_trpcasnn2,strcat(str,'\X_trpcasnn2','.jpg'));
        imwrite(N_trpcasnn2,strcat(str,'\N_trpcasnn2','.jpg'));
        [p_rtc, m_rtc] = psnr(X_rtc, T);
        [s_rtc, ~] = ssim(X_rtc,T);
        [p_obs,m_obs] = psnr(Observed,T);
        [s_obs,~] = ssim(Observed,T);
%         [p_obs2,m_obs2] = Mypsnr(Observed2,T);
%         [s_obs2,~] = ssim(Observed2,T);
        [p_silrtctt, m_silrtctt] = psnr(X_silrtctt, T);
        [s_silrtctt, ~] = ssim(X_silrtctt,T);
        [p_tmactt, m_tmactt] = psnr(X_tmactt, T);
        [s_tmactt, ~] = ssim(X_tmactt,T);
        [p_silrtc, m_silrtc] = psnr(X_silrtc, T);
        [s_silrtc, ~] = ssim(X_silrtc,T);
%         [p_lrtctnn, m_lrtctnn] = Mypsnr(X_lrtctnn, T);
%         [s_lrtctnn, ~] = ssim(X_lrtctnn,T);
        [p_trpcatnn, m_trpcatnn] = psnr(X_trpcatnn, T);
        [s_trpcatnn, ~] = ssim(X_trpcatnn,T);
        [p_trpcatnn2, m_trpcatnn2] = psnr(X_trpcatnn2, T);
        [s_trpcatnn2, ~] = ssim(X_trpcatnn2,T);
        [p_trpcasnn, m_trpcasnn] = psnr(X_trpcasnn, T);
        [s_trpcasnn, ~] = ssim(X_trpcasnn,T);
        [p_trpcasnn2, m_trpcasnn2] = psnr(X_trpcasnn2, T);
        [s_trpcasnn2, ~] = ssim(X_trpcasnn2,T);
        MSEv=[m_rtc,m_silrtctt,m_tmactt,m_silrtc,m_trpcasnn,m_trpcatnn,m_trpcasnn2,m_trpcatnn2];
        SSIMv=[s_rtc,s_silrtctt,s_tmactt,s_silrtc,s_trpcasnn,s_trpcatnn,s_trpcasnn2,s_trpcatnn2];
        PSNRv=[p_rtc,p_silrtctt,p_tmactt,p_silrtc,p_trpcasnn,p_trpcatnn,p_trpcasnn2,p_trpcatnn2];
        save(strcat(str,'\PSNR','.mat'),'PSNRv');
        save(strcat(str,'\MSE','.mat'),'MSEv');
        save(strcat(str,'\SSIM','.mat'),'SSIMv');
        fprintf('The MSE value is RTC:%0.4f. SILRTCTT:%0.4f TMACTT:%0.4f SILRTC:%0.4f  TRPCA_SNN:%0.4f TRPCA_SNN2:%0.4f TRPCA_TNN:%0.4f TRPCA_TNN2:%0.4f\n', m_rtc,m_silrtctt,m_tmactt,m_silrtc,m_trpcasnn,m_trpcasnn2,m_trpcatnn,m_trpcatnn2);
        fprintf('The SSIM value is RTC:%0.4f. SILRTCTT:%0.4f TMACTT:%0.4f SILRTC:%0.4f  TRPCA_SNN:%0.4f TRPCA_SNN2:%0.4f TRPCA_TNN:%0.4f TRPCA_TNN2:%0.4f\n',s_rtc,s_silrtctt,s_tmactt,s_silrtc,s_trpcasnn,s_trpcasnn2,s_trpcatnn,s_trpcatnn2);
        fprintf('The Peak-SNR value is RTC:%0.4f. SILRTCTT:%0.4f TMACTT:%0.4f SILRTC:%0.4f  TRPCA_SNN:%0.4f TRPCA_SNN2:%0.4f TRPCA_TNN:%0.4f TRPCA_TNN2:%0.4f\n', p_rtc,p_silrtctt,p_tmactt,p_silrtc,p_trpcasnn,p_trpcasnn2,p_trpcatnn,p_trpcatnn2);
end


















